package com.mhvi.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mhvi.app.R
import com.mhvi.app.model.CartItem

class CartAdapter(
    private val cartItems: List<CartItem>,
    private val onQuantityChanged: (CartItem, Int) -> Unit,
    private val onItemRemoved: (CartItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartItems[position]
        holder.bind(cartItem)
    }

    override fun getItemCount(): Int = cartItems.size

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.cart_item_title)
        private val priceTextView: TextView = itemView.findViewById(R.id.cart_item_price)
        private val quantityTextView: TextView = itemView.findViewById(R.id.cart_item_quantity)
        private val increaseButton: Button = itemView.findViewById(R.id.cart_item_increase)
        private val decreaseButton: Button = itemView.findViewById(R.id.cart_item_decrease)
        private val removeButton: ImageButton = itemView.findViewById(R.id.cart_item_remove)

        fun bind(cartItem: CartItem) {
            titleTextView.text = cartItem.voucher.title
            priceTextView.text = "${cartItem.voucher.price} ريال" // Or use a proper currency formatter
            quantityTextView.text = cartItem.quantity.toString()

            increaseButton.setOnClickListener {
                val newQuantity = cartItem.quantity + 1
                onQuantityChanged(cartItem, newQuantity)
            }

            decreaseButton.setOnClickListener {
                if (cartItem.quantity > 1) {
                    val newQuantity = cartItem.quantity - 1
                    onQuantityChanged(cartItem, newQuantity)
                } else {
                    // If quantity would become 0, remove the item
                    onItemRemoved(cartItem)
                }
            }

            removeButton.setOnClickListener {
                onItemRemoved(cartItem)
            }
        }
    }
}
