package com.mhvi.app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mhvi.app.adapter.ChatAdapter
import com.mhvi.app.model.ChatMessage
import com.mhvi.app.security.SecurityUtils
import java.util.Date

class ChatActivity : AppCompatActivity() {

    private val TAG = "ChatActivity"
    private lateinit var recyclerView: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button
    private var messageList = mutableListOf<ChatMessage>()
    
    // Placeholder for current user ID and support agent ID
    private val currentUserId = "USER_123" 
    private val supportAgentId = "SUPPORT_AGENT"
    private val currentUserName = "مستخدم MHVI" // Get from user profile

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "الدعم الفني"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Perform security check
        performSecurityCheck()

        // Initialize views
        recyclerView = findViewById(R.id.chat_recycler_view)
        messageEditText = findViewById(R.id.chat_message_input)
        sendButton = findViewById(R.id.chat_send_button)

        // Setup RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true // Start from bottom
        }
        chatAdapter = ChatAdapter(messageList, currentUserId)
        recyclerView.adapter = chatAdapter

        // Load initial messages (placeholder)
        loadMessages()

        // Setup send button
        sendButton.setOnClickListener {
            sendMessage()
        }
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun loadMessages() {
        // Placeholder: In a real app, fetch messages from Firebase Firestore or backend
        Log.d(TAG, "Loading messages (Placeholder)")
        messageList.clear()
        // Add some dummy messages
        messageList.add(ChatMessage("msg1", supportAgentId, "الدعم الفني", currentUserId, "مرحباً! كيف يمكنني مساعدتك اليوم؟", Date(System.currentTimeMillis() - 60000), false))
        messageList.add(ChatMessage("msg2", currentUserId, currentUserName, supportAgentId, "لدي مشكلة في تطبيق كوبون الخصم.", Date(System.currentTimeMillis() - 30000), false))
        
        chatAdapter.notifyDataSetChanged()
        scrollToBottom()
    }

    private fun sendMessage() {
        val messageText = messageEditText.text.toString().trim()
        if (messageText.isNotEmpty()) {
            // Create new message object
            val newMessage = ChatMessage(
                messageId = "msg" + (messageList.size + 1), // Placeholder ID
                senderId = currentUserId,
                senderName = currentUserName,
                receiverId = supportAgentId,
                messageText = messageText,
                timestamp = Date(),
                isRead = false
            )
            
            // Add to list and update UI
            messageList.add(newMessage)
            chatAdapter.notifyItemInserted(messageList.size - 1)
            scrollToBottom()
            
            // Clear input field
            messageEditText.setText("")
            
            // Placeholder: Send message to backend (e.g., Firebase Firestore)
            Log.d(TAG, "Sending message (Placeholder): $messageText")
            // In a real app, implement sending logic here
            
            // Simulate support reply after a delay (for demo)
            // Handler(Looper.getMainLooper()).postDelayed({ simulateSupportReply() }, 2000)
        }
    }
    
    // private fun simulateSupportReply() {
    //     val replyMessage = ChatMessage(
    //         messageId = "msg" + (messageList.size + 1),
    //         senderId = supportAgentId,
    //         senderName = "الدعم الفني",
    //         receiverId = currentUserId,
    //         messageText = "شكراً لتواصلك، سأقوم بالتحقق من مشكلة الكوبون.",
    //         timestamp = Date(),
    //         isRead = false
    //     )
    //     messageList.add(replyMessage)
    //     chatAdapter.notifyItemInserted(messageList.size - 1)
    //     scrollToBottom()
    // }

    private fun scrollToBottom() {
        recyclerView.scrollToPosition(chatAdapter.itemCount - 1)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
