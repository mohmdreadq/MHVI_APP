package com.mhvi.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
// Import Firebase Auth, Google Sign-In, Facebook SDK
// import com.google.firebase.auth.FirebaseAuth
// import com.google.firebase.auth.ktx.auth
// import com.google.firebase.ktx.Firebase
// import com.google.android.gms.auth.api.signin.GoogleSignIn
// import com.google.android.gms.auth.api.signin.GoogleSignInClient
// import com.google.android.gms.auth.api.signin.GoogleSignInOptions
// import com.facebook.CallbackManager
// import com.facebook.FacebookCallback
// import com.facebook.FacebookException
// import com.facebook.login.LoginResult
// import com.facebook.login.widget.LoginButton

class LoginActivity : AppCompatActivity() {

    private val TAG = "LoginActivity"
    // private lateinit var auth: FirebaseAuth
    // private lateinit var googleSignInClient: GoogleSignInClient
    // private lateinit var callbackManager: CallbackManager

    // Placeholder request codes
    private val RC_SIGN_IN = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Firebase Auth
        // auth = Firebase.auth

        // Configure Google Sign-In
        // val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        //     .requestIdToken(getString(R.string.default_web_client_id)) // Get from google-services.json
        //     .requestEmail()
        //     .build()
        // googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Initialize Facebook SDK
        // callbackManager = CallbackManager.Factory.create()

        // Find buttons
        val googleSignInButton: Button = findViewById(R.id.google_sign_in_button)
        val facebookSignInButton: Button = findViewById(R.id.facebook_sign_in_button)
        // val facebookLoginButton: LoginButton = findViewById(R.id.facebook_login_button) // Use official FB button if preferred

        // Google Sign-In Click Listener
        googleSignInButton.setOnClickListener {
            Log.d(TAG, "Google Sign-In button clicked (Placeholder)")
            signInWithGoogle()
        }

        // Facebook Sign-In Click Listener (for custom button)
        facebookSignInButton.setOnClickListener {
            Log.d(TAG, "Facebook Sign-In button clicked (Placeholder)")
            // Trigger Facebook login flow
            // facebookLoginButton.performClick()
            Toast.makeText(this, "Facebook Login (Placeholder)", Toast.LENGTH_SHORT).show()
            // Simulate successful login for now
            navigateToMainActivity()
        }

        // Facebook Login Callback (for official LoginButton)
        // facebookLoginButton.registerCallback(callbackManager, object : FacebookCallback<LoginResult> {
        //     override fun onSuccess(loginResult: LoginResult) {
        //         Log.d(TAG, "Facebook login successful: ${loginResult.accessToken.token}")
        //         handleFacebookAccessToken(loginResult.accessToken)
        //     }
        //     override fun onCancel() {
        //         Log.d(TAG, "Facebook login canceled.")
        //         Toast.makeText(baseContext, "Login Canceled", Toast.LENGTH_LONG).show()
        //     }
        //     override fun onError(error: FacebookException) {
        //         Log.e(TAG, "Facebook login error: ${error.message}")
        //         Toast.makeText(baseContext, "Login Failed: ${error.message}", Toast.LENGTH_LONG).show()
        //     }
        // })
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        // val currentUser = auth.currentUser
        // if (currentUser != null) {
        //     Log.d(TAG, "User already signed in: ${currentUser.uid}")
        //     navigateToMainActivity()
        // }
    }

    private fun signInWithGoogle() {
        // Placeholder: Start Google Sign-In flow
        // val signInIntent = googleSignInClient.signInIntent
        // startActivityForResult(signInIntent, RC_SIGN_IN)
        Toast.makeText(this, "Google Sign-In (Placeholder)", Toast.LENGTH_SHORT).show()
        // Simulate successful login for now
        navigateToMainActivity()
    }

    // Handle Google Sign-In result
    // override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    //     super.onActivityResult(requestCode, resultCode, data)
    //     // Pass the result to the Facebook SDK
    //     callbackManager.onActivityResult(requestCode, resultCode, data)

    //     // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
    //     if (requestCode == RC_SIGN_IN) {
    //         val task = GoogleSignIn.getSignedInAccountFromIntent(data)
    //         try {
    //             // Google Sign In was successful, authenticate with Firebase
    //             val account = task.getResult(ApiException::class.java)!!
    //             Log.d(TAG, "firebaseAuthWithGoogle:${account.id}")
    //             firebaseAuthWithGoogle(account.idToken!!)
    //         } catch (e: ApiException) {
    //             // Google Sign In failed, update UI appropriately
    //             Log.w(TAG, "Google sign in failed", e)
    //             Toast.makeText(this, "Google Sign-In Failed", Toast.LENGTH_SHORT).show()
    //         }
    //     }
    // }

    // Authenticate with Firebase using Google token
    // private fun firebaseAuthWithGoogle(idToken: String) {
    //     val credential = GoogleAuthProvider.getCredential(idToken, null)
    //     auth.signInWithCredential(credential)
    //         .addOnCompleteListener(this) { task ->
    //             if (task.isSuccessful) {
    //                 // Sign in success, update UI with the signed-in user's information
    //                 Log.d(TAG, "signInWithCredential(Google):success")
    //                 val user = auth.currentUser
    //                 navigateToMainActivity()
    //             } else {
    //                 // If sign in fails, display a message to the user.
    //                 Log.w(TAG, "signInWithCredential(Google):failure", task.exception)
    //                 Toast.makeText(baseContext, "Authentication Failed.", Toast.LENGTH_SHORT).show()
    //             }
    //         }
    // }

    // Authenticate with Firebase using Facebook token
    // private fun handleFacebookAccessToken(token: AccessToken) {
    //     Log.d(TAG, "handleFacebookAccessToken:${token}")
    //     val credential = FacebookAuthProvider.getCredential(token.token)
    //     auth.signInWithCredential(credential)
    //         .addOnCompleteListener(this) { task ->
    //             if (task.isSuccessful) {
    //                 // Sign in success, update UI with the signed-in user's information
    //                 Log.d(TAG, "signInWithCredential(Facebook):success")
    //                 val user = auth.currentUser
    //                 navigateToMainActivity()
    //             } else {
    //                 // If sign in fails, display a message to the user.
    //                 Log.w(TAG, "signInWithCredential(Facebook):failure", task.exception)
    //                 Toast.makeText(baseContext, "Authentication Failed.", Toast.LENGTH_SHORT).show()
    //             }
    //         }
    // }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Close LoginActivity
    }
}
