package com.mhvi.app.model

import java.util.Date

data class Voucher(
    val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val imageUrl: String = "", // URL to voucher image
    val category: String = "", // e.g., "Gaming", "Shopping", "Entertainment"
    val expiryDate: Date? = null, // Optional expiry date
    val isActive: Boolean = true // Whether this voucher is currently available
)

data class CartItem(
    val voucher: Voucher,
    var quantity: Int = 1
)

data class Coupon(
    val id: String,
    val code: String,
    val discountAmount: Double? = null, // Fixed amount discount (e.g., 5 IQD off)
    val discountPercentage: Double? = null, // Percentage discount (e.g., 10% off)
    val description: String = "", // Human-readable description
    val minimumPurchase: Double? = null, // Minimum cart value required
    val expiryDate: Date? = null, // When the coupon expires
    val isActive: Boolean = true, // Whether this coupon is currently valid
    val maxUsesPerUser: Int? = null, // How many times a user can use this coupon
    val applicableVoucherIds: List<String>? = null // If null, applies to all vouchers
)

data class ChatMessage(
    val messageId: String,
    val senderId: String,
    val senderName: String,
    val receiverId: String,
    val messageText: String,
    val timestamp: Date,
    var isRead: Boolean = false
)

data class Order(
    val id: String,
    val userId: String,
    val items: List<CartItem>,
    val totalAmount: Double,
    val discountAmount: Double,
    val finalAmount: Double,
    val couponCode: String? = null,
    val paymentMethod: String, // "in_app" or "whatsapp"
    val paymentStatus: String, // "pending", "completed", "failed"
    val orderDate: Date,
    val voucherCodes: Map<String, String>? = null // Voucher ID to actual code mapping
)

data class User(
    val id: String,
    val name: String,
    val email: String,
    val profilePictureUrl: String? = null,
    val isAdmin: Boolean = false,
    val registrationDate: Date,
    val lastLoginDate: Date? = null
)
