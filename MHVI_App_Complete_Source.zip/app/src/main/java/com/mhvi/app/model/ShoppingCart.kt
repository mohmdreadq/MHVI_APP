package com.mhvi.app.model

import android.util.Log

// Simple Singleton object to manage the shopping cart state
// In a real app, consider using a ViewModel, Repository pattern, or local database (Room)
object ShoppingCart {

    private const val TAG = "ShoppingCart"
    val items = mutableListOf<CartItem>()
    private var appliedCoupon: Coupon? = null

    fun addItem(voucher: Voucher, quantity: Int = 1) {
        val existingItem = items.find { it.voucher.id == voucher.id }
        if (existingItem != null) {
            existingItem.quantity += quantity
            Log.d(TAG, "Increased quantity for ${voucher.title} to ${existingItem.quantity}")
        } else {
            items.add(CartItem(voucher, quantity))
            Log.d(TAG, "Added ${voucher.title} (x$quantity) to cart")
        }
    }

    fun removeItem(voucherId: String) {
        val removed = items.removeAll { it.voucher.id == voucherId }
        if (removed) {
            Log.d(TAG, "Removed item with ID $voucherId from cart")
            // Re-evaluate coupon if it depended on the removed item (optional)
            if (appliedCoupon != null && !isCouponStillValid()) {
                 removeCoupon("الكوبون لم يعد صالحاً بعد إزالة المنتج")
            }
        }
    }

    fun updateItemQuantity(voucherId: String, newQuantity: Int) {
        val item = items.find { it.voucher.id == voucherId }
        if (item != null) {
            if (newQuantity > 0) {
                item.quantity = newQuantity
                Log.d(TAG, "Updated quantity for ${item.voucher.title} to $newQuantity")
            } else {
                removeItem(voucherId) // Remove if quantity is zero or less
            }
             // Re-evaluate coupon if it depended on quantity (optional)
            if (appliedCoupon != null && !isCouponStillValid()) {
                 removeCoupon("الكوبون لم يعد صالحاً بعد تغيير الكمية")
            }
        }
    }

    fun clearCart() {
        items.clear()
        appliedCoupon = null
        Log.d(TAG, "Cart cleared")
    }

    fun getItemCount(): Int {
        return items.sumOf { it.quantity }
    }

    fun calculateSubtotal(): Double {
        return items.sumOf { it.voucher.price * it.quantity }
    }

    fun applyCoupon(code: String): Boolean {
        // Placeholder: Fetch coupon details from backend/Firestore based on code
        Log.d(TAG, "Attempting to apply coupon: $code")
        val fetchedCoupon = findCouponByCode(code) // Simulate fetching

        if (fetchedCoupon != null && isCouponValidForCart(fetchedCoupon)) {
            appliedCoupon = fetchedCoupon
            Log.d(TAG, "Applied coupon: ${fetchedCoupon.code} - Discount: ${fetchedCoupon.discountAmount ?: (fetchedCoupon.discountPercentage.toString() + '%')}")
            return true
        } else {
            Log.w(TAG, "Coupon '$code' is invalid or not applicable")
            appliedCoupon = null // Ensure no invalid coupon remains applied
            return false
        }
    }
    
    fun removeCoupon(reason: String? = null) {
        if (appliedCoupon != null) {
            Log.d(TAG, "Removing coupon ${appliedCoupon?.code}. Reason: $reason")
            appliedCoupon = null
        }
    }

    // Placeholder: Simulate fetching coupon from a data source
    private fun findCouponByCode(code: String): Coupon? {
        // In a real app, query Firestore or your backend API
        return when (code.uppercase()) {
            "MHVI10" -> Coupon("C1", "MHVI10", discountPercentage = 10.0, description = "خصم 10% على الطلب")
            "SAVE5" -> Coupon("C2", "SAVE5", discountAmount = 5.0, description = "خصم 5 دينار", minimumPurchase = 30.0)
            "FREESHIP" -> Coupon("C3", "FREESHIP", discountAmount = 0.0, description = "شحن مجاني (مثال)") // Example, might affect shipping cost instead
            else -> null
        }
    }

    // Placeholder: Check coupon validity rules against the current cart
    private fun isCouponValidForCart(coupon: Coupon): Boolean {
        // Basic checks (add more as needed: expiry date, usage limit, specific products)
        val subtotal = calculateSubtotal()
        if (coupon.minimumPurchase != null && subtotal < coupon.minimumPurchase) {
            Log.w(TAG, "Coupon ${coupon.code} requires minimum purchase of ${coupon.minimumPurchase}, cart subtotal is $subtotal")
            return false
        }
        // Add checks for expiry, usage limits, applicable products/categories etc.
        Log.d(TAG, "Coupon ${coupon.code} is valid for the current cart")
        return true
    }
    
    // Check if the currently applied coupon is still valid (e.g., after removing items)
    private fun isCouponStillValid(): Boolean {
        return appliedCoupon != null && isCouponValidForCart(appliedCoupon!!)
    }

    fun calculateDiscount(): Double {
        if (appliedCoupon == null || !isCouponStillValid()) {
            return 0.0
        }

        val subtotal = calculateSubtotal()
        var discount = 0.0

        if (appliedCoupon!!.discountAmount != null) {
            discount = appliedCoupon!!.discountAmount!!
        } else if (appliedCoupon!!.discountPercentage != null) {
            discount = subtotal * (appliedCoupon!!.discountPercentage!! / 100.0)
        }
        
        // Ensure discount doesn't exceed subtotal
        discount = discount.coerceAtMost(subtotal)
        
        Log.d(TAG, "Calculated discount: $discount for coupon ${appliedCoupon?.code}")
        return discount
    }

    fun calculateTotal(): Double {
        val subtotal = calculateSubtotal()
        val discount = calculateDiscount()
        val total = (subtotal - discount).coerceAtLeast(0.0) // Ensure total is not negative
        Log.d(TAG, "Calculated total: $total (Subtotal: $subtotal, Discount: $discount)")
        return total
    }
}
