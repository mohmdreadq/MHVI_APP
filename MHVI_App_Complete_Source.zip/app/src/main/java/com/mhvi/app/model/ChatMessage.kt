package com.mhvi.app.model

import java.util.Date

/**
 * Represents a chat message in the support system
 */
data class ChatMessage(
    val messageId: String,
    val senderId: String,
    val senderName: String,
    val receiverId: String,
    val messageText: String,
    val timestamp: Date,
    var isRead: Boolean = false
)
