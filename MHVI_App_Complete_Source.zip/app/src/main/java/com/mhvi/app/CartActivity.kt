package com.mhvi.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mhvi.app.adapter.CartAdapter
import com.mhvi.app.model.CartItem
import com.mhvi.app.model.ShoppingCart
import com.mhvi.app.security.SecurityUtils
import java.text.NumberFormat
import java.util.Locale

class CartActivity : AppCompatActivity() {

    private val TAG = "CartActivity"
    private lateinit var recyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var subtotalTextView: TextView
    private lateinit var discountTextView: TextView
    private lateinit var totalTextView: TextView
    private lateinit var couponEditText: EditText
    private lateinit var applyCouponButton: Button
    private lateinit var checkoutButton: Button
    private lateinit var emptyCartTextView: TextView
    
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("ar", "IQ")) // Iraqi Dinar format

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "سلة التسوق"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Perform security check
        performSecurityCheck()

        // Initialize views
        recyclerView = findViewById(R.id.cart_recycler_view)
        subtotalTextView = findViewById(R.id.cart_subtotal_value)
        discountTextView = findViewById(R.id.cart_discount_value)
        totalTextView = findViewById(R.id.cart_total_value)
        couponEditText = findViewById(R.id.cart_coupon_code)
        applyCouponButton = findViewById(R.id.cart_apply_coupon_button)
        checkoutButton = findViewById(R.id.cart_checkout_button)
        emptyCartTextView = findViewById(R.id.empty_cart_text)

        // Setup RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        setupAdapter()

        // Setup buttons
        applyCouponButton.setOnClickListener {
            applyCoupon()
        }
        checkoutButton.setOnClickListener {
            navigateToCheckout()
        }

        // Update UI
        updateCartView()
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun setupAdapter() {
        cartAdapter = CartAdapter(
            ShoppingCart.items,
            onQuantityChanged = { cartItem, newQuantity ->
                ShoppingCart.updateItemQuantity(cartItem.voucher.id, newQuantity)
                updateCartView() // Update totals and adapter
            },
            onItemRemoved = { cartItem ->
                ShoppingCart.removeItem(cartItem.voucher.id)
                Toast.makeText(this, "تمت إزالة ${cartItem.voucher.title}", Toast.LENGTH_SHORT).show()
                updateCartView() // Update totals and adapter
            }
        )
        recyclerView.adapter = cartAdapter
    }

    private fun updateCartView() {
        // Update adapter data (in case items were added/removed elsewhere)
        cartAdapter.notifyDataSetChanged() 
        
        // Update totals
        val subtotal = ShoppingCart.calculateSubtotal()
        val discount = ShoppingCart.calculateDiscount()
        val total = ShoppingCart.calculateTotal()

        subtotalTextView.text = currencyFormat.format(subtotal)
        discountTextView.text = "- ${currencyFormat.format(discount)}"
        totalTextView.text = currencyFormat.format(total)
        
        // Show/hide empty cart message
        if (ShoppingCart.items.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyCartTextView.visibility = View.VISIBLE
            checkoutButton.isEnabled = false
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyCartTextView.visibility = View.GONE
            checkoutButton.isEnabled = true
        }
        
        Log.d(TAG, "Cart view updated. Items: ${ShoppingCart.getItemCount()}")
    }

    private fun applyCoupon() {
        val couponCode = couponEditText.text.toString().trim()
        if (couponCode.isNotEmpty()) {
            val applied = ShoppingCart.applyCoupon(couponCode)
            if (applied) {
                Toast.makeText(this, "تم تطبيق الكوبون بنجاح", Toast.LENGTH_SHORT).show()
                updateCartView()
            } else {
                Toast.makeText(this, "كوبون غير صالح", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "الرجاء إدخال كود الكوبون", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToCheckout() {
        if (ShoppingCart.items.isNotEmpty()) {
            val intent = Intent(this, CheckoutActivity::class.java)
            startActivity(intent)
        } else {
            Toast.makeText(this, "سلة التسوق فارغة", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
