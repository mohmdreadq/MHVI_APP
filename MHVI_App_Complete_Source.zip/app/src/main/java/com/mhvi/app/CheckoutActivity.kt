package com.mhvi.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mhvi.app.model.ShoppingCart
import com.mhvi.app.security.SecurityUtils
import java.net.URLEncoder
import java.text.NumberFormat
import java.util.Locale

class CheckoutActivity : AppCompatActivity() {

    private val TAG = "CheckoutActivity"
    private lateinit var totalAmountTextView: TextView
    private lateinit var paymentMethodRadioGroup: RadioGroup
    private lateinit var inAppPaymentRadioButton: RadioButton
    private lateinit var whatsappPaymentRadioButton: RadioButton
    private lateinit var couponEditText: EditText
    private lateinit var applyCouponButton: Button
    private lateinit var confirmPaymentButton: Button
    
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("ar", "IQ")) // Iraqi Dinar format
    private val whatsappNumber = "+9647733957778" // User provided WhatsApp number

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "الدفع"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Perform security check
        performSecurityCheck()

        // Initialize views
        totalAmountTextView = findViewById(R.id.checkout_total_amount)
        paymentMethodRadioGroup = findViewById(R.id.payment_method_group)
        inAppPaymentRadioButton = findViewById(R.id.radio_in_app_payment)
        whatsappPaymentRadioButton = findViewById(R.id.radio_whatsapp_payment)
        couponEditText = findViewById(R.id.checkout_coupon_code)
        applyCouponButton = findViewById(R.id.checkout_apply_coupon_button)
        confirmPaymentButton = findViewById(R.id.checkout_confirm_button)

        // Update total amount display
        updateTotalAmount()

        // Setup buttons
        applyCouponButton.setOnClickListener {
            applyCoupon()
        }
        confirmPaymentButton.setOnClickListener {
            processPayment()
        }
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun updateTotalAmount() {
        val total = ShoppingCart.calculateTotal()
        totalAmountTextView.text = currencyFormat.format(total)
        Log.d(TAG, "Checkout total updated: ${currencyFormat.format(total)}")
    }

    private fun applyCoupon() {
        val couponCode = couponEditText.text.toString().trim()
        if (couponCode.isNotEmpty()) {
            val applied = ShoppingCart.applyCoupon(couponCode)
            if (applied) {
                Toast.makeText(this, "تم تطبيق الكوبون بنجاح", Toast.LENGTH_SHORT).show()
                updateTotalAmount() // Update total after applying coupon
            } else {
                Toast.makeText(this, "كوبون غير صالح", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "الرجاء إدخال كود الكوبون", Toast.LENGTH_SHORT).show()
        }
    }

    private fun processPayment() {
        val selectedPaymentMethodId = paymentMethodRadioGroup.checkedRadioButtonId

        if (selectedPaymentMethodId == -1) {
            Toast.makeText(this, "الرجاء اختيار طريقة الدفع", Toast.LENGTH_SHORT).show()
            return
        }

        val totalAmount = ShoppingCart.calculateTotal()

        when (selectedPaymentMethodId) {
            R.id.radio_in_app_payment -> {
                Log.d(TAG, "Processing In-App Payment (Placeholder)")
                // Placeholder: Integrate with a payment gateway SDK (e.g., Stripe, Braintree)
                // This would involve server-side interaction as well
                Toast.makeText(this, "جاري معالجة الدفع داخل التطبيق (مثال)", Toast.LENGTH_LONG).show()
                // Simulate success for now
                handlePaymentSuccess()
            }
            R.id.radio_whatsapp_payment -> {
                Log.d(TAG, "Initiating WhatsApp Payment")
                initiateWhatsAppPayment(totalAmount)
            }
        }
    }

    private fun initiateWhatsAppPayment(amount: Double) {
        try {
            val formattedAmount = currencyFormat.format(amount)
            // Construct a pre-filled message for WhatsApp
            val message = "مرحباً، أود إتمام عملية شراء من تطبيق MHVI بقيمة $formattedAmount. تفاصيل الطلب: ..."
            // In a real app, include order details (items, quantities) in the message
            
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val whatsappUrl = "https://wa.me/$whatsappNumber?text=$encodedMessage"
            
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(whatsappUrl)
            intent.setPackage("com.whatsapp") // Ensure it opens in WhatsApp

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                // Note: This only opens WhatsApp. Confirmation needs to be handled manually
                // or via a backend system that monitors WhatsApp messages (complex).
                Toast.makeText(this, "سيتم توجيهك إلى واتساب لإتمام الدفع", Toast.LENGTH_LONG).show()
                // For now, assume payment will be confirmed manually later
                // handlePaymentSuccess() // Don't call this automatically
            } else {
                Toast.makeText(this, "تطبيق واتساب غير مثبت", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initiating WhatsApp payment", e)
            Toast.makeText(this, "حدث خطأ أثناء محاولة فتح واتساب", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handlePaymentSuccess() {
        // Placeholder: Clear cart, save order details to backend, navigate to confirmation screen
        Log.d(TAG, "Payment successful (Placeholder)")
        ShoppingCart.clearCart()
        Toast.makeText(this, "تم الدفع بنجاح!", Toast.LENGTH_LONG).show()
        // Navigate to an order confirmation or back to main activity
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
