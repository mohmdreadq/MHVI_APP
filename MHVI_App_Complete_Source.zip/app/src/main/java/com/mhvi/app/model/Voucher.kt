package com.mhvi.app.model

/**
 * Data class representing a voucher in the MHVI app.
 */
data class Voucher(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val imageUrl: String? = null,
    val isActive: Boolean = true
)
