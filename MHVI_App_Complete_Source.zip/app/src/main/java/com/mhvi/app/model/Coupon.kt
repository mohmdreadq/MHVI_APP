package com.mhvi.app.model

import java.util.Date

/**
 * Data class representing a discount coupon in the MHVI app.
 */
data class Coupon(
    val id: String,
    val code: String, // The code users enter
    val description: String,
    val discountType: DiscountType,
    val discountValue: Double, // Either percentage (e.g., 10.0 for 10%) or fixed amount
    val expiryDate: Date? = null,
    val minPurchaseAmount: Double? = null,
    val maxUsageCount: Int? = null,
    val currentUsageCount: Int = 0,
    val isActive: Boolean = true
)

enum class DiscountType {
    PERCENTAGE,
    FIXED_AMOUNT
}

