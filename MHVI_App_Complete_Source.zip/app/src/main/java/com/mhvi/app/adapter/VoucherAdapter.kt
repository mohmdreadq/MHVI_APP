package com.mhvi.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mhvi.app.R
import com.mhvi.app.model.Voucher

class VoucherAdapter(
    private val vouchers: List<Voucher>,
    private val onVoucherClick: (Voucher) -> Unit
) : RecyclerView.Adapter<VoucherAdapter.VoucherViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VoucherViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_voucher, parent, false)
        return VoucherViewHolder(view)
    }

    override fun onBindViewHolder(holder: VoucherViewHolder, position: Int) {
        val voucher = vouchers[position]
        holder.bind(voucher)
    }

    override fun getItemCount(): Int = vouchers.size

    inner class VoucherViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.voucher_title)
        private val priceTextView: TextView = itemView.findViewById(R.id.voucher_price)
        private val voucherImageView: ImageView = itemView.findViewById(R.id.voucher_image)
        private val addToCartButton: ImageButton = itemView.findViewById(R.id.voucher_add_to_cart)

        fun bind(voucher: Voucher) {
            titleTextView.text = voucher.title
            priceTextView.text = "${voucher.price} ريال" // Or use a proper currency formatter

            // Load image using Glide or Picasso (commented out as libraries not included yet)
            // if (voucher.imageUrl.isNotEmpty()) {
            //     Glide.with(itemView.context)
            //         .load(voucher.imageUrl)
            //         .placeholder(R.drawable.placeholder_voucher)
            //         .error(R.drawable.error_voucher)
            //         .into(voucherImageView)
            // } else {
            //     voucherImageView.setImageResource(R.drawable.placeholder_voucher)
            // }

            // Set placeholder image for now
            // voucherImageView.setImageResource(R.drawable.placeholder_voucher)

            // Set click listeners
            itemView.setOnClickListener {
                // Open voucher details or add to cart directly
                onVoucherClick(voucher)
            }

            addToCartButton.setOnClickListener {
                // Add to cart directly
                onVoucherClick(voucher)
            }
        }
    }
}
