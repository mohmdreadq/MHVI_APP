package com.mhvi.app.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.provider.Settings
import android.util.Log
import java.io.File

object SecurityUtils {

    private const val TAG = "SecurityUtils"

    // List of known rooting packages/files/binaries
    // This list is not exhaustive and can be bypassed
    private val knownRootPaths = arrayOf(
        "/system/app/Superuser.apk",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/su",
        "/su/bin/su"
    )

    // List of known packages associated with Lucky Patcher or similar tools
    // This list is also not exhaustive
    private val knownPatchingApps = arrayOf(
        "com.chelpus.lackypatch",
        "com.dimonvideo.luckypatcher",
        "com.forpda.lp",
        "com.android.vending.billing.InAppBillingService.LOCK", // Older LP artifact
        "com.android.vending.billing.InAppBillingService.LUCK", // Older LP artifact
        "com.android.vending.billing.InAppBillingService.LACK"
        // Add more known package names if needed
    )

    /**
     * Performs a series of security checks.
     * Returns true if a potential security issue is detected, false otherwise.
     */
    fun performSecurityChecks(context: Context): Boolean {
        Log.d(TAG, "Performing security checks...")
        var issueDetected = false

        if (isRooted()) {
            Log.w(TAG, "Potential root detected.")
            issueDetected = true
        }

        if (isDebuggable(context)) {
            Log.w(TAG, "Application is debuggable.")
            // Note: This might be true during development, check build type if needed
            // issueDetected = true // Usually okay in debug builds
        }

        if (isRunningOnEmulator()) {
            Log.w(TAG, "Application might be running on an emulator.")
            // Decide if running on an emulator is a security risk for your app
            // issueDetected = true
        }

        if (detectPatchingApps(context)) {
            Log.w(TAG, "Known patching application detected.")
            issueDetected = true
        }

        Log.d(TAG, "Security checks completed. Issue detected: $issueDetected")
        return issueDetected
    }

    /**
     * Checks for the presence of known root indicators.
     * This is a basic check and can be easily bypassed.
     */
    private fun isRooted(): Boolean {
        for (path in knownRootPaths) {
            if (File(path).exists()) {
                Log.w(TAG, "Root indicator found: $path")
                return true
            }
        }
        // Add check for `which su` command execution if possible/reliable
        return false
    }

    /**
     * Checks if the application is marked as debuggable in the manifest.
     */
    private fun isDebuggable(context: Context): Boolean {
        return (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    /**
     * Basic emulator detection.
     * Can be bypassed.
     */
    private fun isRunningOnEmulator(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk" == Build.PRODUCT)
    }

    /**
     * Detects if known patching apps (like Lucky Patcher) are installed.
     */
    private fun detectPatchingApps(context: Context): Boolean {
        val pm = context.packageManager
        for (packageName in knownPatchingApps) {
            try {
                pm.getPackageInfo(packageName, 0) // Check if package exists
                Log.w(TAG, "Detected known patching app: $packageName")
                return true
            } catch (e: Exception) {
                // Package not found, continue checking
            }
        }
        return false
    }

    // --- Additional Potential Checks (More Advanced) ---

    // Check for Developer Options enabled (can be a weak indicator)
    fun areDeveloperOptionsEnabled(context: Context): Boolean {
        return Settings.Secure.getInt(context.contentResolver,
            Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
    }

    // Check for ADB enabled (can be a weak indicator)
    fun isAdbEnabled(context: Context): Boolean {
        return Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    }

    // Tamper Detection (Requires comparing current signature with original)
    // fun isAppTampered(context: Context): Boolean { ... complex implementation ... }

    // Hook Detection (Check for frameworks like Xposed, Substrate)
    // fun detectHooks(): Boolean { ... complex and often unreliable ... }
}
