package com.mhvi.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.mhvi.app.adapter.VoucherAdapter
import com.mhvi.app.model.ShoppingCart
import com.mhvi.app.model.Voucher
import com.mhvi.app.security.SecurityUtils

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private lateinit var recyclerView: RecyclerView
    private lateinit var voucherAdapter: VoucherAdapter
    private lateinit var fabCart: FloatingActionButton
    private var voucherList = mutableListOf<Voucher>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "MHVI - القسائم الإلكترونية"

        // Perform security check
        performSecurityCheck()

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.voucher_recycler_view)
        recyclerView.layoutManager = GridLayoutManager(this, 2) // 2 columns grid

        // Initialize FAB
        fabCart = findViewById(R.id.fab_cart)
        fabCart.setOnClickListener {
            navigateToCart()
        }

        // Load voucher data (placeholder)
        loadVouchers()

        // Setup Adapter
        voucherAdapter = VoucherAdapter(voucherList) { voucher ->
            // Handle voucher click - add to cart
            addToCart(voucher)
        }
        recyclerView.adapter = voucherAdapter

        // Update cart badge initially
        updateCartBadge()
    }

    override fun onResume() {
        super.onResume()
        // Update cart badge when returning to this activity
        updateCartBadge()
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun loadVouchers() {
        // Placeholder: In a real app, fetch from Firebase Firestore or backend API
        Log.d(TAG, "Loading vouchers (Placeholder)")
        voucherList.clear()
        voucherList.add(Voucher("1", "قسيمة Google Play $10", "وصف قسيمة جوجل بلاي", 10.0, "", "Google Play"))
        voucherList.add(Voucher("2", "قسيمة Netflix شهر", "اشتراك نتفلكس", 15.0, "", "Netflix"))
        voucherList.add(Voucher("3", "قسيمة Amazon $25", "رصيد أمازون", 25.0, "", "Amazon"))
        voucherList.add(Voucher("4", "قسيمة Steam $20", "رصيد ستيم للألعاب", 20.0, "", "Steam"))
        voucherList.add(Voucher("5", "قسيمة iTunes $15", "رصيد آيتونز", 15.0, "", "iTunes"))
        voucherList.add(Voucher("6", "قسيمة PUBG 600 UC", "شدات ببجي موبايل", 10.0, "", "PUBG Mobile"))
        
        // Notify adapter about data changes
        if (::voucherAdapter.isInitialized) {
            voucherAdapter.notifyDataSetChanged()
        }
    }

    private fun addToCart(voucher: Voucher) {
        ShoppingCart.addItem(voucher)
        Log.d(TAG, "Added ${voucher.title} to cart")
        Toast.makeText(this, "تمت إضافة ${voucher.title} إلى السلة", Toast.LENGTH_SHORT).show()
        updateCartBadge()
    }

    private fun updateCartBadge() {
        val itemCount = ShoppingCart.getItemCount()
        // Placeholder: Update a badge on the FAB or toolbar icon
        // For simplicity, just log the count for now
        Log.d(TAG, "Cart item count: $itemCount")
        // You might use a library like `com.nex3z:notification-badge` for the FAB badge
        // Or update a menu item's action view if using a toolbar cart icon
    }

    private fun navigateToCart() {
        val intent = Intent(this, CartActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToSupportChat() {
        val intent = Intent(this, ChatActivity::class.java)
        // Pass necessary info like user ID, support agent ID if needed
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_profile -> {
                navigateToProfile()
                true
            }
            R.id.action_support -> {
                navigateToSupportChat()
                true
            }
            // Add case for Admin Panel if the user is an admin
            // R.id.action_admin -> { ... }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
