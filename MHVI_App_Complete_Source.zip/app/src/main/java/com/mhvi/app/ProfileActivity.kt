package com.mhvi.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mhvi.app.security.SecurityUtils
// Import Firebase Auth
// import com.google.firebase.auth.FirebaseAuth
// import com.google.firebase.auth.ktx.auth
// import com.google.firebase.ktx.Firebase

class ProfileActivity : AppCompatActivity() {

    private val TAG = "ProfileActivity"
    // private lateinit var auth: FirebaseAuth

    private lateinit var userNameTextView: TextView
    private lateinit var userEmailTextView: TextView
    private lateinit var logoutButton: Button
    private lateinit var adminPanelButton: Button // Only visible for admins

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "الملف الشخصي"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Perform security check
        performSecurityCheck()

        // Initialize Firebase Auth
        // auth = Firebase.auth

        // Initialize views
        userNameTextView = findViewById(R.id.profile_user_name)
        userEmailTextView = findViewById(R.id.profile_user_email)
        logoutButton = findViewById(R.id.profile_logout_button)
        adminPanelButton = findViewById(R.id.profile_admin_panel_button)

        // Load user data
        loadUserProfile()

        // Setup buttons
        logoutButton.setOnClickListener {
            signOut()
        }
        
        adminPanelButton.setOnClickListener {
             navigateToAdminPanel()
        }

        // Check if user is admin and show/hide admin button
        checkAdminStatus()
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun loadUserProfile() {
        // Placeholder: Get user info from Firebase Auth or local storage
        // val currentUser = auth.currentUser
        // if (currentUser != null) {
        //     userNameTextView.text = currentUser.displayName ?: "اسم المستخدم"
        //     userEmailTextView.text = currentUser.email ?: "البريد الإلكتروني"
        //     Log.d(TAG, "User profile loaded: ${currentUser.email}")
        // } else {
        //     // Handle case where user is not logged in (shouldn't happen if activity is protected)
        //     Log.w(TAG, "User not logged in in ProfileActivity")
        //     userNameTextView.text = "مستخدم غير مسجل"
        //     userEmailTextView.text = ""
        //     logoutButton.isEnabled = false
        // }
        
        // Placeholder data
        userNameTextView.text = "علي أحمد"
        userEmailTextView.text = "ali.ahmed@example.com"
        Log.d(TAG, "Loading user profile (Placeholder)")
    }

    private fun checkAdminStatus() {
        // Placeholder: Check if the current user has admin privileges
        // This usually involves checking a custom claim in Firebase Auth token
        // or querying a user role from Firestore/Database.
        val isAdmin = true // Simulate admin user for now
        Log.d(TAG, "Checking admin status (Placeholder): isAdmin = $isAdmin")
        
        if (isAdmin) {
            adminPanelButton.visibility = android.view.View.VISIBLE
        } else {
            adminPanelButton.visibility = android.view.View.GONE
        }
    }

    private fun signOut() {
        Log.d(TAG, "Signing out user (Placeholder)")
        // Firebase sign out
        // auth.signOut()
        
        // Optional: Sign out from Google and Facebook if used
        // GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN).signOut()
        // com.facebook.login.LoginManager.getInstance().logOut()

        Toast.makeText(this, "تم تسجيل الخروج", Toast.LENGTH_SHORT).show()

        // Navigate back to LoginActivity
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    private fun navigateToAdminPanel() {
        val intent = Intent(this, AdminDashboardActivity::class.java)
        startActivity(intent)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
