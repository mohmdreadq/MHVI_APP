package com.mhvi.app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mhvi.app.security.SecurityUtils

class AdminDashboardActivity : AppCompatActivity() {

    private val TAG = "AdminDashboardActivity"

    private lateinit var manageVouchersButton: Button
    private lateinit var manageCouponsButton: Button
    private lateinit var viewOrdersButton: Button
    private lateinit var manageUsersButton: Button // Optional

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        // Setup toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "لوحة تحكم المدير"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Perform security check (important for admin panel)
        performSecurityCheck()
        // Add extra check to ensure only admins can access this activity
        verifyAdminAccess()

        // Initialize views
        manageVouchersButton = findViewById(R.id.admin_manage_vouchers_button)
        manageCouponsButton = findViewById(R.id.admin_manage_coupons_button)
        viewOrdersButton = findViewById(R.id.admin_view_orders_button)
        manageUsersButton = findViewById(R.id.admin_manage_users_button)

        // Setup button listeners
        manageVouchersButton.setOnClickListener {
            // Placeholder: Navigate to Manage Vouchers Activity
            Log.d(TAG, "Manage Vouchers clicked (Placeholder)")
            Toast.makeText(this, "إدارة القسائم (مثال)", Toast.LENGTH_SHORT).show()
            // val intent = Intent(this, AdminManageVouchersActivity::class.java)
            // startActivity(intent)
        }

        manageCouponsButton.setOnClickListener {
            // Placeholder: Navigate to Manage Coupons Activity
            Log.d(TAG, "Manage Coupons clicked (Placeholder)")
            Toast.makeText(this, "إدارة الكوبونات (مثال)", Toast.LENGTH_SHORT).show()
            // val intent = Intent(this, AdminManageCouponsActivity::class.java)
            // startActivity(intent)
        }

        viewOrdersButton.setOnClickListener {
            // Placeholder: Navigate to View Orders Activity
            Log.d(TAG, "View Orders clicked (Placeholder)")
            Toast.makeText(this, "عرض الطلبات (مثال)", Toast.LENGTH_SHORT).show()
            // val intent = Intent(this, AdminViewOrdersActivity::class.java)
            // startActivity(intent)
        }

        manageUsersButton.setOnClickListener {
            // Placeholder: Navigate to Manage Users Activity
            Log.d(TAG, "Manage Users clicked (Placeholder)")
            Toast.makeText(this, "إدارة المستخدمين (مثال)", Toast.LENGTH_SHORT).show()
            // val intent = Intent(this, AdminManageUsersActivity::class.java)
            // startActivity(intent)
        }
    }

    private fun performSecurityCheck() {
        val securityIssue = SecurityUtils.performSecurityChecks(this)
        if (securityIssue) {
            Log.w(TAG, "Security issue detected!")
            Toast.makeText(this, "تم اكتشاف مشكلة أمنية في الجهاز", Toast.LENGTH_LONG).show()
            // Consider limiting functionality or exiting
        }
    }

    private fun verifyAdminAccess() {
        // Placeholder: Verify if the current logged-in user is actually an admin.
        // This should be a robust check, potentially involving re-authentication
        // or checking server-side roles again.
        val isAdmin = true // Assume true for now, replace with real check
        Log.d(TAG, "Verifying admin access (Placeholder): isAdmin = $isAdmin")
        if (!isAdmin) {
            Log.e(TAG, "Unauthorized access attempt to Admin Dashboard!")
            Toast.makeText(this, "غير مصرح لك بالدخول", Toast.LENGTH_LONG).show()
            // Redirect to main activity or login
            // val intent = Intent(this, MainActivity::class.java)
            // intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            // startActivity(intent)
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
