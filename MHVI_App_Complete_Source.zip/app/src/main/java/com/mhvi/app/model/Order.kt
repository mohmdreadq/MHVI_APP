package com.mhvi.app.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

/**
 * Data class representing a user order in the MHVI app.
 */
data class Order(
    val orderId: String = "",
    val userId: String = "",
    val userEmail: String = "", // For easier display in admin panel
    val items: List<CartItem> = emptyList(),
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val total: Double = 0.0,
    val appliedCouponCode: String? = null,
    val paymentMethod: String = "", // e.g., "in_app", "whatsapp"
    var orderStatus: String = OrderStatus.PENDING.name, // e.g., PENDING, PROCESSING, COMPLETED, CANCELLED, PENDING_WHATSAPP
    @ServerTimestamp
    val orderDate: Date? = null,
    val lastUpdateDate: Date? = null
) {
    // Add a no-argument constructor if needed for Firebase deserialization
    constructor() : this("", "", "", emptyList(), 0.0, 0.0, 0.0, null, "", OrderStatus.PENDING.name, null, null)
}

enum class OrderStatus {
    PENDING, // Initial state, awaiting payment confirmation
    PENDING_WHATSAPP, // Awaiting manual confirmation for WhatsApp payment
    PROCESSING, // Payment confirmed, order being processed (if needed)
    COMPLETED, // Order fulfilled
    CANCELLED // Order cancelled
}

